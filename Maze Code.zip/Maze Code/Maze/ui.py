# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'designerxuXxLw.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################
from PyQt5.QtCore import pyqtSlot
from PySide6.QtCore import *
from PySide6.QtGui import *
from PySide6.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(800, 600)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.pushButton = QPushButton(self.centralwidget)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(40, 10, 93, 28))
        self.pushButton_2 = QPushButton(self.centralwidget)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(250, 10, 93, 28))
        self.comboBox = QComboBox(self.centralwidget)
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.addItem("")
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setGeometry(QRect(420, 10, 101, 22))
        self.comboBox.setFrame(False)
        self.spinBox = QSpinBox(self.centralwidget)
        self.spinBox.setObjectName(u"spinBox")
        self.spinBox.setGeometry(QRect(600, 10, 42, 22))
        self.spinBox.setFrame(False)
        self.spinBox.setMinimum(5)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 800, 26))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.pushButton_2.clicked.connect(self.generate_maze)
        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"Generate Maze", None))
        self.pushButton_2.setText(QCoreApplication.translate("MainWindow", u"Draw Maze", None))
        self.comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"Breadth-First ", None))
        self.comboBox.setItemText(1, QCoreApplication.translate("MainWindow", u"Depth-First", None))
        self.comboBox.setItemText(2, QCoreApplication.translate("MainWindow", u"Greedy", None))
        self.comboBox.setItemText(3, QCoreApplication.translate("MainWindow", u"A*", None))
        

    # retranslateUi
    #@pyqtSlot()
    def generate_maze(self):
    # Implement your logic to generate a maze based on the matrix_size
    # You can replace this with your actual maze generation algorithm
        # maze = [['.' for _ in range(matrix_size)] for _ in range(matrix_size)]
        # return maze
        matrix_size=self.spinBox.value()
        print(f"Button clicked {matrix_size}")

class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.ui.pushButton_2.clicked.connect(self.generate_maze_button_clicked)

    def generate_maze_button_clicked(self):
        print("Hello")
        matrix_size = self.ui.spinBox.value()
        maze = Ui_MainWindow.generate_maze(matrix_size)

        # Create a widget to display the maze (replace this with your actual visualization)
        maze_widget = QWidget(self)
        maze_widget.setGeometry(QRect(100, 100, matrix_size * 20, matrix_size * 20))

        for i in range(matrix_size):
            for j in range(matrix_size):
                label = QLabel(maze[i][j], maze_widget)
                label.setGeometry(QRect(j * 20, i * 20, 20, 20))
                label.setAlignment(Qt.AlignCenter)
                label.setStyleSheet("border: 1px solid black;")


if __name__=="__main__":
    import sys
    app=QApplication(sys.argv)
    MainWindow=QMainWindow()
    ui=Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    
    sys.exit(app.exec_())